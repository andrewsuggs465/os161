
hog.o: \
 hog.c

